<?php
require_once '../core/Router.php';
Router::handle();