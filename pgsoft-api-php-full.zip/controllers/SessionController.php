<?php
require_once '../core/Helpers.php';
json_response(['token' => uniqid('token_')]);