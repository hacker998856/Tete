<?php
$gamePath = dirname($_SERVER['PHP_SELF']) . '/../game/index.html';
?>
<!DOCTYPE html>
<html>
<head>
  <title>เข้าเกม PGSOFT</title>
  <style>html,body{margin:0;padding:0;height:100%;}</style>
</head>
<body>
  <iframe src="<?= $gamePath ?>" width="100%" height="100%" frameborder="0" allowfullscreen></iframe>
</body>
</html>
