<?php
require_once '../core/Helpers.php';
header('Location: /views/iframe-game.php');
exit;