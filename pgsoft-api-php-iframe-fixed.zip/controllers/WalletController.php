<?php
require_once '../core/Helpers.php';
json_response(['balance' => 1000]);