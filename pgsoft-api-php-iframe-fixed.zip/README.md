# PGSOFT API (PHP Version)

- Place your HTML5 game in `public/game/`
- API endpoints:
  - `/session/create`
  - `/wallet/balance`
  - `/forward`