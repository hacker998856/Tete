<?php
class Router {
  public static function handle() {
    $uri = $_SERVER['REQUEST_URI'];
    if (preg_match('#^/session/create$#', $uri)) require '../controllers/SessionController.php';
    elseif (preg_match('#^/wallet/balance$#', $uri)) require '../controllers/WalletController.php';
    elseif (preg_match('#^/forward$#', $uri)) require '../controllers/ForwardController.php';
    else echo '404 Not Found';
  }
}